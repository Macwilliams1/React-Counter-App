import React, { useState } from "react";
import "./Counter.css";

function Counter() {
  const [count, setCount] = useState(0);
  const limit = 10;

  const increase = () => {
    if (count < limit) {
      setCount(count + 1);
    }
  };

  const decrease = () => {
    if (count > 0) {
      setCount(count - 1);
    }
  };

  return (
    <div className="counter-container">
      <h1>Counter App</h1>
      <p className="count-value">{count}</p>
      
      {count === limit && (
        <p className="limit-message">🎉 You've reached the limit!</p>
      )}

      <div className="button-group">
        <button onClick={increase} className="btn increase">Increase</button>
        <button onClick={decrease} className="btn decrease">Decrease</button>
      </div>
    </div>
  );
}

export default Counter;
