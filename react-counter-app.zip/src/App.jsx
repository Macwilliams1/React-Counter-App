import React from 'react'
import Counter from './Counter'

function App() {
  return (
    <main>
      <Counter />
    </main>
  )
}

export default App
